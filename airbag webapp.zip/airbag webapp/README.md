# AMATEC Airbag Production Dashboard

A frontend-only production and scrap monitor for AMATEC Airbag. Load an Excel
or CSV report to analyze production in the browser. The dashboard does not use a
backend or send uploaded records to Netlify or another service.

## Requirements

- Node.js and npm (use a current Node.js LTS release)
- Git for version control and GitHub-based deployment

## Get started

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. Run the tests and create/preview a
production build with:

```sh
npm test
npm run build
npm run preview
```

## Load a report

Choose **Load data** and select `.xlsx`, `.xls`, or `.csv`. Excel workbooks use
the `AMATEC Airbag report` worksheet when present and must contain the required
production columns. The supplied `AMATEC Airbag.xlsx` workbook is not bundled or
loaded automatically; select it from your own files when testing.

The latest successfully loaded dataset is stored in this browser's IndexedDB.
It stays on this browser/device and may be removed with **Clear stored data** or
by clearing browser data. Uploading a replacement does not discard the current
dataset if the replacement file is invalid or cannot be saved.

## Classification

- `Error Code = 0` (including numeric text zero) is a good piece.
- A valid nonzero `Error Code` is a scrap piece.
- Missing or nonnumeric error codes are unclassified and excluded from piece
  counts and scrap rates.
- Scrap rate is scrap pieces divided by classified pieces; a zero-piece result
  has a rate of 0%.

The dashboard contains five charts and a scrap-only records table. The filters
above the timestamp chart apply to that chart and the table; each breakdown
chart has its own independent set of five filters. Each filter allows multiple
selected values; values within one field are alternatives, while different
fields are combined. The Error Code chart counts nonzero scrap codes and has
its own independent filters. Every chart groups by Timestamp; the breakdown
charts show the selected Project, Machine, Operator, or Error Code within each
time interval. Technical measurements are displayed as record details only and
are not treated as defect indicators.

## Project structure

```text
public/                     Static assets copied to the build output
src/
  css/                      Global, layout, component, and dashboard styles
  js/
    app.js                  Page wiring and browser interactions
    config.js               Column names, filters, and shared configuration
    excelProcessor.js       Local Excel/CSV parsing and schema validation
    dataProcessor.js        Classification, filtering, and aggregation
    database.js             IndexedDB dataset persistence
    filters.js              Cascading, independently scoped chart filters
    charts.js               The five Chart.js visualizations
    table.js                Scrap table, details, sort, search, and export
tests/                      Focused data-processing tests
docs/                       Roadmap, architecture, and deployment guidance
index.html                  Dashboard page and semantic markup
netlify.toml                Static Netlify build and response headers
package.json                Scripts and project dependencies
```

See [docs/PROJECT_ROADMAP.md](docs/PROJECT_ROADMAP.md) and
[docs/TECHNICAL_ARCHITECTURE.md](docs/TECHNICAL_ARCHITECTURE.md) for the
architecture and planned work.
