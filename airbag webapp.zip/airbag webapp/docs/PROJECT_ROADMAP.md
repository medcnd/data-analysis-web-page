# Project Roadmap

## Objectives

Provide a lightweight, static AMATEC Airbag production-quality dashboard. Data
is selected by the user, processed in the browser, and saved only in that
browser's IndexedDB. Hosting remains static on Netlify; no backend or database
server is used.

## Phases and completion criteria

### Phase 1 — Project environment and infrastructure (complete)

- Established the HTML/CSS/vanilla JavaScript project and Vite scripts.
- Configured static Netlify publishing and response headers.
- Added responsive baseline styles and project documentation.

### Phase 2 — Production and scrap dashboard (implemented)

- Import `.xlsx`, `.xls`, and `.csv` reports locally; prefer worksheet
  `AMATEC Airbag report` and validate required column headers.
- Classify records from `Error Code`, preserving unclassified rows and
  preventing division by zero.
- Display five charts grouped by Timestamp: production over time, plus
  Project/Machine/Operator breakdowns and nonzero scrap counts by Error Code
  within each time interval. Give every chart its own Hour/Day/Month grouping.
- Provide five cascading filters above the timestamp chart for that chart and
  the scrap table, plus independent five-filter sets and reset actions for each
  breakdown chart. Allow multiple values to be selected in each filter.
- Show scrap records only, with search, sorting, pagination, full record
  details, and filtered Excel export.
- Persist the most recently successful dataset in IndexedDB, restore it on
  reload, allow replacement and clearing, and explain local-only storage.
- Verify with the supplied four-record workbook: four good pieces, zero scrap,
  zero unclassified, and a 0% scrap rate.

**Dependencies:** Phase 1.

**Completion criteria**

- File contents stay in the browser; invalid imports or failed saves do not
  replace the last successfully saved dataset.
- Filters, charts, and the scrap table update from the imported records.
- Saved data restores after a page reload and can be removed by the user.
- No extra dashboard page, KPI cards, or unrequested visualizations are added.

### Phase 3 — Quality, accessibility, and usability (planned)

- Test representative browsers, mobile/tablet layouts, keyboard operation, and
  assistive-technology semantics.
- Exercise larger workbooks and document practical browser memory/storage
  limits.
- Test malformed, empty, partially populated, and mixed-type records, plus
  IndexedDB quota and recovery behavior.
- Review dependency updates and refine user-facing guidance based on testing.

**Dependencies:** Phase 2.

**Completion criteria**

- Agreed accessibility, browser-compatibility, and performance checks pass.
- Users can understand how data is stored, cleared, and exported.

### Phase 4 — Release and ongoing maintenance (planned)

- Connect the GitHub repository to Netlify and verify production settings.
- Verify the deployed site over HTTPS and configure a custom domain if needed.
- Document release, rollback, and dependency-update routines.

**Dependencies:** Phase 1 deployment setup; production release should follow
Phase 3 validation.

**Completion criteria**

- Netlify can rebuild the static site from the repository.
- A maintainer can update and redeploy the site using the deployment guide.

## Future improvements

- Add a web worker for spreadsheet parsing if profiling shows it is needed.
- Add automated browser-level checks for upload, replacement, and persistence.
- Add export/backup options or additional import formats only when user needs
  justify the added complexity.

Any future improvement must preserve the frontend-only architecture and must
not transmit user datasets without explicit, separately reviewed product
requirements and consent.
