# Technical Architecture

## Application architecture

The application is a static, client-side site. Vite serves it during
development and builds deployable files into `dist/`. The browser loads
`index.html`, then native JavaScript modules, CSS, Chart.js, and (on demand)
SheetJS. There is no API, backend, server database, or analytics integration.

The Excel library is loaded only when the user imports or exports a spreadsheet.
Chart.js is used for five charts. The project remains vanilla JavaScript without
a UI framework.

## Folder structure

```text
public/                     Static files copied unchanged to dist/
src/
  css/
    main.css                Global tokens and baseline styles
    layout.css              Page and responsive layout
    components.css          Buttons, controls, notices, and record dialog
    dashboard.css           Chart cards and scrap table
  js/
    app.js                  Page setup, state, events, and dataset lifecycle
    config.js               Required columns, filters, database, and colors
    excelProcessor.js       SheetJS parsing, column validation, timestamp parsing
    dataProcessor.js        Error classification, summaries, filters, aggregation
    database.js             IndexedDB open/save/load/delete transactions
    filters.js              Cascading filter options for independent chart filters
    charts.js               Chart.js configuration for the five charts
    table.js                Scrap-only table, details, sort, search, export
tests/
  dataProcessor.test.js     Classification, summary, filter, and time tests
docs/                       Roadmap, architecture, and deployment guides
index.html                  The single dashboard page
netlify.toml                Static build settings and response headers
package.json                Scripts and project dependencies
```

## Technology

- HTML5, CSS3, and vanilla JavaScript ES modules.
- Vite for development and static production builds.
- SheetJS (`xlsx` 0.20.3 from the official SheetJS CDN tarball) for local Excel
  and CSV processing and Excel export.
- Chart.js for interactive grouped-bar and scrap-rate line charts.
- IndexedDB for the latest locally saved dataset.
- Netlify for static hosting. No user dataset is sent to Netlify.

## Import and classification flow

1. The user chooses an `.xlsx`, `.xls`, or `.csv` file through the page's file
   picker.
2. `excelProcessor.js` reads the file in the browser, prefers the worksheet
   named `AMATEC Airbag report`, locates the header row, validates the required
   columns, skips completely empty rows, and converts Excel serial timestamps
   into JavaScript `Date` objects.
3. Each non-empty row remains a production record; records are counted, not
   distinct IDs. `dataProcessor.js` classifies `Error Code = 0` as good,
   numeric nonzero values as scrap, and missing/nonnumeric values as
   unclassified.
4. Classified records with valid timestamps feed all five charts. The main
   chart groups by Timestamp; Project, Machine, and Operator charts show
   category labels beneath one centered timestamp label per interval; the Error
   Code chart counts nonzero scrap codes within each timestamp interval.
   Records with invalid timestamps remain in the scrap table and data-quality
   summary but are omitted from charts.
5. The five multi-select filters above the timestamp chart apply only to that
   chart and the scrap-only table. Each project, machine, operator, and Error
   Code chart has its own independent set of five cascading multi-select filters
   and reset action. Multiple values in one field are combined as alternatives;
   different fields are combined together. Search and sorting/pagination
   operate on scrap records filtered by the top set.
6. Only after parsing and validation succeed does the application save the new
   dataset in IndexedDB and replace its in-memory dataset. A failed parse or
   save leaves the previous dataset intact.

The app does not load sample data on its own. The supplied workbook is selected
by the user and is not included in the repository or production build.

## Chart definitions

The production charts use grouped bars for good and scrap record counts and a
line for scrap rate, with the percentage on a 0–100 secondary axis. Breakdown
charts group category ticks under one timestamp label per interval, with
separators between intervals; tooltips show both the interval and category.
The Error Code chart uses bars to count scrap records for each nonzero Error
Code in each time interval.

1. Timestamp: Hour, Day, or Month grouping, based only on `Timestamp`.
2. Timestamp and Project: time interval and `Type Group`.
3. Timestamp and Machine: time interval and `Machine ID`.
4. Timestamp and Operator: time interval and `Login Name`.
5. Timestamp and Error Code: time interval and nonzero `Error Code`.

Each chart has an independent Hour/Day/Month selector. All selectors group
records using the `Timestamp` column, never `Time Elasp` or `Time El SAB`.

No separate KPI-card section or unrequested visualizations are included.
Technical measurements are available in record details but are not used to
classify quality.

## IndexedDB storage

`database.js` owns the database named `amatec-airbag-dashboard` and the
`datasets` object store. The store uses a single `current` key for the latest
successful report. The saved value contains the source filename, import time,
worksheet name, original headers, and normalized row records.

Saving uses an IndexedDB write transaction; replacing the `current` record is
atomic. Dataset values, including timestamp `Date` objects and all source
columns, are structured-cloned by the browser. The app reloads this record on
startup and provides a user-controlled clear action. Browser storage may be
cleared or evicted and does not synchronize across browsers/devices.

## Security and privacy

- Workbook parsing, filtering, aggregation, charting, and export run in the
  browser. Uploaded contents are not sent to a server or third party.
- Imported values are untrusted. UI values are inserted as text, not executable
  HTML.
- The importer validates the required columns and reports invalid classifications
  and timestamps instead of treating them as good or silently dropping them.
- No imported data or personal values are written to console logs.
- The dataset can be removed from the current browser. Users should understand
  that browser storage is device/profile-specific and is not a backup.
- Frontend source and static build artifacts are public; do not put credentials
  or private datasets in the repository.
- Keep the SheetJS and Chart.js dependency versions under review and use HTTPS
  for the deployed site.
