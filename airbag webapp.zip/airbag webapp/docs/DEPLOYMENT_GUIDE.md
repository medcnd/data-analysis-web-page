# Deployment Guide

## Prerequisites

- Install a current Node.js LTS release; npm is included with Node.js.
- Install Git if using GitHub-based version control or deployment.
- Have access to a Netlify account for hosted deployment.

## Run locally

Open the project folder in VS Code, then use its integrated terminal:

```sh
npm install
npm run dev
```

Vite prints a local URL (normally `http://localhost:5173`). Open it in a
browser. The development server supports hot reload while files are edited.

## Build and preview

Create the production site:

```sh
npm test
npm run build
```

Vite writes the optimized static site to `dist/`. Preview that build locally
with:

```sh
npm run preview
```

Use the preview URL printed by Vite to check the production output before
deployment.

## Deploy with Netlify and GitHub

1. Create a Git repository for the project, commit the source, and push it to
   GitHub.
2. In Netlify, choose **Add new site** / **Import an existing project**, then
   authorize GitHub and select the repository.
3. Configure the build command as `npm run build` and the publish directory as
   `dist`. These values are also recorded in `netlify.toml`.
4. Start the deployment. Netlify installs dependencies, runs the build, and
   publishes the generated static files.
5. Open the deployed site and confirm the AMATEC dashboard loads over HTTPS.

Uploaded spreadsheets are processed in the user's browser and stored in that
browser's IndexedDB. Netlify hosts only the static application; it does not
receive the contents of uploaded files.

Netlify can also detect the settings from `netlify.toml`; check the site build
settings if the dashboard shows different values. No SPA rewrite is configured
because this project has no client-side router.

## Manual Netlify deployment

Build locally with `npm run build`, then drag the generated `dist/` directory
into Netlify's manual deploy interface. Manual deployment does not automatically
rebuild when source files change.

## Update the deployed site

For a GitHub-connected site, make and test changes locally, commit them, and
push to the connected branch. Netlify will run `npm run build` and deploy a new
version. Review the deploy log and open the published site to verify it.

For manual deployment, rebuild with `npm run build` and upload the new `dist/`
directory. Keep the source repository as the canonical project; do not edit
generated files in `dist/` directly.
