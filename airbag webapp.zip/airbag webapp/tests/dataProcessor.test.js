import test from "node:test";
import assert from "node:assert/strict";
import {
  aggregateByCategory,
  aggregateByTime,
  aggregateByTimeAndCategory,
  aggregateScrapByTimeAndErrorCode,
  classifyErrorCode,
  filterRecords,
  summarizeRecords,
} from "../src/js/dataProcessor.js";
import { parseTimestamp } from "../src/js/excelProcessor.js";

function record(errorCode, timestamp, values = {}) {
  const date = timestamp ? new Date(timestamp) : null;
  const classification = classifyErrorCode(errorCode);
  return {
    values: {
      "Error Code": errorCode,
      "Type Group": "Project A",
      "Machine ID": "Machine 1",
      "Login Name": "Operator A",
      "Prod Part N": "Part 1",
      "Produ Name": "Product A",
      ...values,
    },
    timestamp: date && !Number.isNaN(date.getTime()) ? date : null,
    classification,
  };
}

test("classifies numeric and text zero, nonzero values, and unclassified codes", () => {
  assert.equal(classifyErrorCode(0), "good");
  assert.equal(classifyErrorCode("0"), "good");
  assert.equal(classifyErrorCode(" 0.0 "), "good");
  assert.equal(classifyErrorCode(7), "scrap");
  assert.equal(classifyErrorCode("-1"), "scrap");
  assert.equal(classifyErrorCode("invalid"), "unclassified");
  assert.equal(classifyErrorCode(""), "unclassified");
  assert.equal(classifyErrorCode(null), "unclassified");
});

test("counts only classified pieces and guards a zero-piece scrap rate", () => {
  const records = [record(0, "2026-03-08T10:00:00Z"), record(2, null), record("", null)];
  const summary = summarizeRecords(records);

  assert.deepEqual(
    {
      totalRecords: summary.totalRecords,
      totalPieces: summary.totalPieces,
      good: summary.good,
      scrap: summary.scrap,
      unclassified: summary.unclassified,
      invalidTimestamps: summary.invalidTimestamps,
      scrapRate: summary.scrapRate,
    },
    {
      totalRecords: 3,
      totalPieces: 2,
      good: 1,
      scrap: 1,
      unclassified: 1,
      invalidTimestamps: 2,
      scrapRate: 50,
    },
  );
  assert.equal(summarizeRecords([record("", null)]).scrapRate, 0);
});

test("aggregates timestamps by hour, calendar day, and month", () => {
  const records = [
    record(0, "2026-03-08T10:05:00Z"),
    record("1", "2026-03-08T10:45:00Z"),
    record(0, "2026-03-08T11:05:00Z"),
    record(0, "2026-04-01T00:05:00Z"),
    record("", "2026-03-08T10:15:00Z"),
  ];

  assert.equal(aggregateByTime(records, "hour").length, 3);
  assert.equal(aggregateByTime(records, "day").length, 2);
  assert.equal(aggregateByTime(records, "month").length, 2);
  assert.equal(aggregateByTime(records, "hour")[0].scrapRate, 50);
});

test("category groups count records and filters remain interconnected", () => {
  const records = [
    record(0, "2026-03-08T10:00:00Z", { "Type Group": "Project A" }),
    record("1", "2026-03-08T10:05:00Z", { "Type Group": "Project A" }),
    record(0, "2026-03-08T11:00:00Z", {
      "Type Group": "Project B",
      "Machine ID": "Machine 2",
    }),
  ];
  const groups = aggregateByCategory(records, "Type Group");
  const filtered = filterRecords(records, {
    "Type Group": ["value:Project A"],
    "Machine ID": ["value:Machine 1"],
    "Login Name": [],
    "Prod Part N": [],
    "Produ Name": [],
  });

  assert.equal(groups[0].good, 1);
  assert.equal(groups[0].scrap, 1);
  assert.equal(filtered.length, 2);
});

test("supports multiple values within a filter and combines filter fields", () => {
  const records = [
    record(0, "2026-03-08T10:00:00Z", {
      "Type Group": "Project A",
      "Machine ID": "Machine 1",
    }),
    record(0, "2026-03-08T10:05:00Z", {
      "Type Group": "Project B",
      "Machine ID": "Machine 1",
    }),
    record(0, "2026-03-08T10:10:00Z", {
      "Type Group": "Project C",
      "Machine ID": "Machine 1",
    }),
    record(0, "2026-03-08T10:15:00Z", {
      "Type Group": "Project A",
      "Machine ID": "Machine 2",
    }),
  ];

  const filtered = filterRecords(records, {
    "Type Group": ["value:Project A", "value:Project B"],
    "Machine ID": ["value:Machine 1"],
    "Login Name": [],
    "Prod Part N": [],
    "Produ Name": [],
  });

  assert.equal(filtered.length, 2);
  assert.deepEqual(
    filtered.map((item) => item.values["Type Group"]),
    ["Project A", "Project B"],
  );
});

test("breakdown charts group good and scrap counts by timestamp and category", () => {
  const records = [
    record(0, "2026-03-08T10:00:00Z", { "Type Group": "Project A" }),
    record(2, "2026-03-08T10:05:00Z", { "Type Group": "Project A" }),
    record(0, "2026-03-08T10:10:00Z", { "Type Group": "Project B" }),
    record(0, "2026-03-08T11:00:00Z", { "Type Group": "Project A" }),
    record("", "2026-03-08T10:15:00Z", { "Type Group": "Project A" }),
    record(0, null, { "Type Group": "Project C" }),
  ];
  const groups = aggregateByTimeAndCategory(records, "hour", "Type Group");
  const dayGroups = aggregateByTimeAndCategory(records, "day", "Type Group");
  const monthGroups = aggregateByTimeAndCategory(records, "month", "Type Group");

  assert.equal(groups.length, 3);
  assert.equal(dayGroups.length, 2);
  assert.equal(monthGroups.length, 2);
  assert.equal(groups[0].intervalKey, groups[1].intervalKey);
  assert.notEqual(groups[1].intervalKey, groups[2].intervalKey);
  assert.deepEqual(
    groups.map(({ categoryLabel, good, scrap, scrapRate }) => ({
      category: categoryLabel,
      good,
      scrap,
      scrapRate,
    })),
    [
      { category: "Project A", good: 1, scrap: 1, scrapRate: 50 },
      { category: "Project B", good: 1, scrap: 0, scrapRate: 0 },
      { category: "Project A", good: 1, scrap: 0, scrapRate: 0 },
    ],
  );
  assert.ok(groups.every(({ intervalLabel, timeGroupLabel }) => intervalLabel && timeGroupLabel));
});

test("Error Code chart counts scrap codes within each timestamp interval", () => {
  const groups = aggregateScrapByTimeAndErrorCode(
    [
      record(0, "2026-03-08T10:00:00Z"),
      record(2, "2026-03-08T10:05:00Z"),
      record("2.0", "2026-03-08T10:10:00Z"),
      record("7", "2026-03-09T10:15:00Z"),
      record("invalid", "2026-03-08T10:20:00Z"),
      record(7, null),
    ],
    "day",
  );

  assert.deepEqual(
    groups.map(({ categoryLabel, count }) => ({ code: categoryLabel, count })),
    [
      { code: "2", count: 2 },
      { code: "7", count: 1 },
    ],
  );
  assert.ok(groups.every(({ intervalLabel, timeGroupLabel }) => intervalLabel && timeGroupLabel));
});

test("parses Excel serials and common CSV dates as the same calendar timestamp", () => {
  const expected = "2026-04-08T00:03:16.000Z";
  assert.equal(parseTimestamp(46120.0022685185).toISOString(), expected);
  assert.equal(parseTimestamp("4/8/2026 12:03:16 AM").toISOString(), expected);
  assert.equal(parseTimestamp("2026-04-08 00:03:16").toISOString(), expected);
  assert.equal(parseTimestamp("2026-02-30 00:00:00"), null);
});
