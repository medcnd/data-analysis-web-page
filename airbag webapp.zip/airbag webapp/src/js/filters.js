import { FILTER_FIELDS } from "./config.js";
import {
  displayFilterValue,
  filterRecords,
  valueToFilterToken,
} from "./dataProcessor.js";

export function createFilterControls(container) {
  const fields = FILTER_FIELDS.map(({ key, label }) => {
    const field = document.createElement("div");
    field.className = "filter-field";

    const fieldLabel = document.createElement("span");
    fieldLabel.textContent = label;

    const dropdown = document.createElement("details");
    dropdown.className = "multi-filter";
    dropdown.dataset.filter = key;

    const summary = document.createElement("summary");
    summary.dataset.filterSummary = key;
    summary.textContent = "All";
    summary.setAttribute("aria-label", `Selected values for ${label}`);

    const options = document.createElement("div");
    options.className = "multi-filter-options";
    options.dataset.filterOptions = key;
    options.setAttribute("role", "group");
    options.setAttribute("aria-label", `${label} options`);

    const clearButton = document.createElement("button");
    clearButton.className = "multi-filter-clear";
    clearButton.type = "button";
    clearButton.dataset.clearFilter = key;
    clearButton.textContent = "Clear selection";
    options.append(clearButton);

    dropdown.append(summary, options);
    field.append(fieldLabel, dropdown);
    return field;
  });

  container.replaceChildren(...fields);
}

function getSelectedValues(filters, key) {
  const selected = filters[key];
  if (Array.isArray(selected)) {
    return selected;
  }
  return selected ? [selected] : [];
}

function updateFilterSummary(container, key, label, selectedValues, options) {
  const summary = container.querySelector(`[data-filter-summary="${key}"]`);
  const selectedLabels = selectedValues
    .map((value) => options.get(value))
    .filter(Boolean);

  summary.textContent =
    selectedLabels.length === 0
      ? "All"
      : selectedLabels.length === 1
        ? selectedLabels[0]
        : `${selectedLabels.length} selected`;
  summary.title = selectedLabels.join(", ") || "All values";
  summary.setAttribute(
    "aria-label",
    `Filter by ${label}. ${selectedLabels.length ? `Selected: ${selectedLabels.join(", ")}` : "All values"}`,
  );
}

export function updateFilterOptions(container, records, filters) {
  for (let pass = 0; pass < FILTER_FIELDS.length; pass += 1) {
    let changed = false;

    FILTER_FIELDS.forEach(({ key, label }) => {
      const selectedValues = getSelectedValues(filters, key);
      if (selectedValues.length === 0) {
        return;
      }

      const availableRecords = filterRecords(records, filters, key);
      const availableValues = new Set(
        availableRecords.map((record) => valueToFilterToken(record.values[key])),
      );
      const validSelections = selectedValues.filter((value) => availableValues.has(value));

      if (validSelections.length !== selectedValues.length) {
        filters[key] = validSelections;
        changed = true;
      }
    });

    if (!changed) {
      break;
    }
  }

  FILTER_FIELDS.forEach(({ key, label }) => {
    const availableRecords = filterRecords(records, filters, key);
    const options = new Map();

    availableRecords.forEach((record) => {
      const value = record.values[key];
      const token = valueToFilterToken(value);
      options.set(token, displayFilterValue(value));
    });

    const selectedValues = getSelectedValues(filters, key);
    const optionRows = [...options.entries()]
      .sort((left, right) =>
        left[1].localeCompare(right[1], undefined, { numeric: true, sensitivity: "base" }),
      )
      .map(([value, label]) => {
        const option = document.createElement("label");
        option.className = "multi-filter-option";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.dataset.filterValue = value;
        checkbox.checked = selectedValues.includes(value);

        const optionLabel = document.createElement("span");
        optionLabel.textContent = label;

        option.append(checkbox, optionLabel);
        return option;
      });

    const optionList = container.querySelector(`[data-filter-options="${key}"]`);
    const clearButton = optionList.querySelector(`[data-clear-filter="${key}"]`);
    clearButton.disabled = selectedValues.length === 0;
    optionList.replaceChildren(clearButton, ...optionRows);
    updateFilterSummary(container, key, label, selectedValues, options);
  });
}

export function bindFilterControls(container, records, filters, onChange) {
  FILTER_FIELDS.forEach(({ key }) => {
    const dropdown = container.querySelector(`[data-filter="${key}"]`);

    dropdown.addEventListener("change", (event) => {
      const checkbox = event.target;
      if (!(checkbox instanceof HTMLInputElement) || !checkbox.dataset.filterValue) {
        return;
      }

      const selectedValues = new Set(getSelectedValues(filters, key));
      if (checkbox.checked) {
        selectedValues.add(checkbox.dataset.filterValue);
      } else {
        selectedValues.delete(checkbox.dataset.filterValue);
      }
      filters[key] = [...selectedValues];
      updateFilterOptions(container, records(), filters);
      onChange();
    });

    dropdown.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }

      const clearButton = target.closest(`[data-clear-filter="${key}"]`);
      if (!clearButton) {
        return;
      }

      filters[key] = [];
      updateFilterOptions(container, records(), filters);
      onChange();
    });
  });

  updateFilterOptions(container, records(), filters);
}
