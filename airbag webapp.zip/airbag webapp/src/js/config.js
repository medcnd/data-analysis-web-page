export const APP_NAME = "AMATEC Airbag";
export const WORKSHEET_NAME = "AMATEC Airbag report";
export const DATABASE_NAME = "amatec-airbag-dashboard";
export const DATABASE_VERSION = 1;
export const DATASET_STORE = "datasets";
export const CURRENT_DATASET_KEY = "current";

export const REQUIRED_COLUMNS = [
  "Type Group",
  "Machine ID",
  "Login Name",
  "Prod Part N",
  "Produ Name",
  "Error Code",
  "Timestamp",
  "ID",
  "Ext Serial",
  "End Lbl Cod",
  "Customr Pn",
  "Login Surn",
  "Max Sew Rpm",
  "TENS1mind",
  "TENS1maxd",
  "TENS1avgd",
  "SAB1St Cnt",
  "Time Elasp",
  "Time El SAB",
];

export const FILTER_FIELDS = [
  { key: "Type Group", label: "Type Group (Project)" },
  { key: "Machine ID", label: "Machine ID" },
  { key: "Login Name", label: "Login Name (Operator)" },
  { key: "Prod Part N", label: "Prod Part N (Product Part Number)" },
  { key: "Produ Name", label: "Produ Name (Product Name)" },
];

export const SCRAP_TABLE_COLUMNS = [
  "Timestamp",
  "ID",
  "Error Code",
  "Type Group",
  "Machine ID",
  "Login Name",
  "Login Surn",
  "Prod Part N",
  "Produ Name",
  "End Lbl Cod",
  "Ext Serial",
  "TENS1mind",
  "TENS1maxd",
  "TENS1avgd",
];

export const CHART_COLORS = {
  good: "#16855d",
  scrap: "#c54445",
  rate: "#3565ad",
  grid: "#e8edf1",
  text: "#526174",
};
