import { SCRAP_TABLE_COLUMNS } from "./config.js";
import { formatTimestamp } from "./dataProcessor.js";

const PAGE_SIZE = 10;

function displayValue(value) {
  if (value === null || value === undefined || value === "") {
    return "—";
  }
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return formatTimestamp(value);
  }
  return String(value);
}

function displayRecordValue(record, field) {
  if (field === "Timestamp") {
    return record.timestamp ? formatTimestamp(record.timestamp) : displayValue(record.values[field]);
  }
  return displayValue(record.values[field]);
}

function compareValues(left, right) {
  if (left === null || left === undefined || left === "") {
    return right === null || right === undefined || right === "" ? 0 : -1;
  }
  if (right === null || right === undefined || right === "") {
    return 1;
  }
  if (left instanceof Date && right instanceof Date) {
    return left.getTime() - right.getTime();
  }

  const leftNumber = Number(left);
  const rightNumber = Number(right);
  if (
    String(left).trim() !== "" &&
    String(right).trim() !== "" &&
    Number.isFinite(leftNumber) &&
    Number.isFinite(rightNumber)
  ) {
    return leftNumber - rightNumber;
  }

  return String(left).localeCompare(String(right), undefined, {
    numeric: true,
    sensitivity: "base",
  });
}

function createCell(value, className = "") {
  const cell = document.createElement("td");
  if (className) {
    cell.className = className;
  }
  cell.textContent = value;
  return cell;
}

export function initializeScrapTable({
  tableBody,
  searchInput,
  countText,
  rangeText,
  pageText,
  previousButton,
  nextButton,
  exportButton,
  dialog,
  dialogTitle,
  dialogContent,
  onExportError,
}) {
  let records = [];
  let headers = [];
  let page = 1;
  let sortField = "Timestamp";
  let sortDirection = "desc";

  function getMatchingRecords() {
    const query = searchInput.value.trim().toLocaleLowerCase();
    const matching = records.filter((record) => {
      if (!query) {
        return true;
      }

      return [...Object.values(record.values), formatTimestamp(record.timestamp)].some(
        (value) => displayValue(value).toLocaleLowerCase().includes(query),
      );
    });

    return matching.sort((left, right) => {
      const leftValue =
        sortField === "Timestamp" ? left.timestamp : left.values[sortField];
      const rightValue =
        sortField === "Timestamp" ? right.timestamp : right.values[sortField];
      return compareValues(leftValue, rightValue) * (sortDirection === "asc" ? 1 : -1);
    });
  }

  function showDetails(record) {
    const recordId = displayValue(record.values.ID);
    dialogTitle.textContent = `Record ${recordId}`;
    dialogContent.replaceChildren();

    headers.forEach((header) => {
      const term = document.createElement("dt");
      term.textContent = header;
      const description = document.createElement("dd");
      description.textContent = displayRecordValue(record, header);
      dialogContent.append(term, description);
    });

    dialog.showModal();
  }

  function render() {
    const matching = getMatchingRecords();
    const pageCount = Math.ceil(matching.length / PAGE_SIZE);
    page = Math.min(Math.max(page, 1), Math.max(pageCount, 1));
    const start = (page - 1) * PAGE_SIZE;
    const pageRecords = matching.slice(start, start + PAGE_SIZE);
    tableBody.replaceChildren();

    if (pageRecords.length === 0) {
      const row = document.createElement("tr");
      const message = searchInput.value.trim()
        ? "No scrap records match this search."
        : records.length === 0
          ? "No scrap records match the current filters."
          : "No scrap records are available.";
      row.append(createCell(message, "table-empty"));
      row.firstElementChild.colSpan = SCRAP_TABLE_COLUMNS.length + 1;
      tableBody.append(row);
    } else {
      pageRecords.forEach((record) => {
        const row = document.createElement("tr");
        SCRAP_TABLE_COLUMNS.forEach((field) => {
          row.append(createCell(displayRecordValue(record, field)));
        });

        const actionCell = document.createElement("td");
        const detailsButton = document.createElement("button");
        detailsButton.className = "text-button";
        detailsButton.type = "button";
        detailsButton.textContent = "View";
        detailsButton.setAttribute(
          "aria-label",
          `View full details for record ${displayValue(record.values.ID)}`,
        );
        detailsButton.addEventListener("click", () => showDetails(record));
        actionCell.append(detailsButton);
        row.append(actionCell);
        tableBody.append(row);
      });
    }

    const firstRecord = matching.length === 0 ? 0 : start + 1;
    const lastRecord = start + pageRecords.length;
    countText.textContent = `${matching.length.toLocaleString()} matching scrap ${
      matching.length === 1 ? "record" : "records"
    } · ${records.length.toLocaleString()} for current filters`;
    rangeText.textContent =
      matching.length === 0
        ? "No records to display"
        : `Showing ${firstRecord.toLocaleString()}–${lastRecord.toLocaleString()} of ${matching.length.toLocaleString()}`;
    pageText.textContent = `Page ${pageCount === 0 ? 0 : page} of ${pageCount}`;
    previousButton.disabled = page <= 1;
    nextButton.disabled = pageCount === 0 || page >= pageCount;
    exportButton.disabled = matching.length === 0;

    document.querySelectorAll("[data-sort-header]").forEach((header) => {
      header.removeAttribute("aria-sort");
      if (header.dataset.sortHeader === sortField) {
        header.setAttribute(
          "aria-sort",
          sortDirection === "asc" ? "ascending" : "descending",
        );
      }
    });
  }

  document.querySelectorAll("[data-sort]").forEach((button) => {
    button.addEventListener("click", () => {
      if (sortField === button.dataset.sort) {
        sortDirection = sortDirection === "asc" ? "desc" : "asc";
      } else {
        sortField = button.dataset.sort;
        sortDirection = "asc";
      }
      page = 1;
      render();
    });
  });

  searchInput.addEventListener("input", () => {
    page = 1;
    render();
  });
  previousButton.addEventListener("click", () => {
    page -= 1;
    render();
  });
  nextButton.addEventListener("click", () => {
    page += 1;
    render();
  });
  exportButton.addEventListener("click", async () => {
    const matching = getMatchingRecords();
    if (matching.length === 0 || headers.length === 0) {
      return;
    }

    try {
      const XLSX = await import("xlsx");
      const worksheet = XLSX.utils.aoa_to_sheet([
        headers,
        ...matching.map((record) =>
          headers.map((header) =>
            header === "Timestamp"
              ? record.timestamp ?? record.values[header] ?? ""
              : record.values[header] ?? "",
          ),
        ),
      ]);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Filtered scrap records");
      XLSX.writeFile(
        workbook,
        `amatec-scrap-records-${new Date().toISOString().slice(0, 10)}.xlsx`,
        { compression: true },
      );
    } catch (error) {
      onExportError(error);
    }
  });

  return {
    update(nextRecords, nextHeaders) {
      records = nextRecords;
      headers = nextHeaders;
      page = 1;
      render();
    },
  };
}
