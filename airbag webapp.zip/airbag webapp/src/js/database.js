import {
  CURRENT_DATASET_KEY,
  DATABASE_NAME,
  DATABASE_VERSION,
  DATASET_STORE,
} from "./config.js";

let databasePromise;

function openDatabase() {
  if (!globalThis.indexedDB) {
    return Promise.reject(new Error("IndexedDB is unavailable in this browser."));
  }

  if (!databasePromise) {
    databasePromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);

      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(DATASET_STORE)) {
          database.createObjectStore(DATASET_STORE, { keyPath: "id" });
        }
      };

      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => {
          database.close();
          databasePromise = null;
        };
        resolve(database);
      };

      request.onerror = () => {
        databasePromise = null;
        reject(request.error ?? new Error("Could not open the local dataset database."));
      };

      request.onblocked = () => {
        databasePromise = null;
        reject(
          new Error("The local database is blocked. Close other copies of this dashboard and retry."),
        );
      };
    });
  }

  return databasePromise;
}

function runTransaction(mode, action) {
  return openDatabase().then(
    (database) =>
      new Promise((resolve, reject) => {
        const transaction = database.transaction(DATASET_STORE, mode);
        const request = action(transaction.objectStore(DATASET_STORE));
        let result;

        if (request) {
          request.onsuccess = () => {
            result = request.result;
          };
          request.onerror = () => {
            reject(request.error ?? new Error("The local database request failed."));
          };
        }

        transaction.oncomplete = () => resolve(result);
        transaction.onerror = () => {
          reject(transaction.error ?? new Error("The local database transaction failed."));
        };
        transaction.onabort = () => {
          reject(transaction.error ?? new Error("The local database transaction was aborted."));
        };
      }),
  );
}

export function saveDataset(dataset) {
  return runTransaction("readwrite", (store) =>
    store.put({ ...dataset, id: CURRENT_DATASET_KEY }),
  );
}

export function loadDataset() {
  return runTransaction("readonly", (store) => store.get(CURRENT_DATASET_KEY));
}

export function clearDataset() {
  return runTransaction("readwrite", (store) => store.delete(CURRENT_DATASET_KEY));
}
