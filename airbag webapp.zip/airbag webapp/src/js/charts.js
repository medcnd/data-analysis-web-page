import {
  BarController,
  BarElement,
  CategoryScale,
  Chart,
  Legend,
  LinearScale,
  LineController,
  LineElement,
  PointElement,
  Tooltip,
} from "chart.js";
import { CHART_COLORS } from "./config.js";

Chart.register(
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  LineController,
  LineElement,
  PointElement,
  Tooltip,
  Legend,
);

function formatChartValue(value) {
  return new Intl.NumberFormat().format(value);
}

function fitAxisLabel(context, value, maxWidth) {
  let label = String(value);
  if (maxWidth <= 0) {
    return "";
  }

  while (label && context.measureText(`${label}…`).width > maxWidth) {
    label = label.slice(0, -1);
  }

  return label === String(value) ? label : `${label}…`;
}

const timestampCategoryAxisPlugin = {
  id: "timestampCategoryAxis",
  afterDraw(chart) {
    const groups = chart.$timestampCategoryGroups;
    const xScale = chart.scales.x;
    if (!groups?.length || !xScale) {
      return;
    }

    const intervals = [];
    let start = 0;
    for (let index = 1; index <= groups.length; index += 1) {
      if (index === groups.length || groups[index].intervalKey !== groups[start].intervalKey) {
        intervals.push({
          start,
          end: index - 1,
          label: groups[start].timeGroupLabel,
        });
        start = index;
      }
    }

    const { ctx, chartArea } = chart;
    const pointX = (index) => xScale.getPixelForValue(index);
    const intervalY = chartArea.bottom + 12;
    const categoryLabelHeight =
      Number(xScale.options.ticks.padding ?? 0) + Chart.defaults.font.size * 2 + 8;

    ctx.save();
    ctx.font = `600 10px ${Chart.defaults.font.family}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = CHART_COLORS.text;
    ctx.strokeStyle = CHART_COLORS.grid;
    ctx.lineWidth = 1;

    intervals.forEach((interval, index) => {
      const firstX = pointX(interval.start);
      const lastX = pointX(interval.end);
      const left = interval.start === 0
        ? chartArea.left
        : (pointX(interval.start - 1) + firstX) / 2;
      const right = interval.end === groups.length - 1
        ? chartArea.right
        : (lastX + pointX(interval.end + 1)) / 2;
      const center = (left + right) / 2;

      if (index > 0) {
        const boundary = left;
        ctx.beginPath();
        ctx.moveTo(boundary + 0.5, chartArea.bottom + 2);
        ctx.lineTo(boundary + 0.5, chartArea.bottom + categoryLabelHeight);
        ctx.stroke();
      }

      const label = fitAxisLabel(ctx, interval.label, right - left - 8);
      if (label) {
        ctx.fillText(label, center, intervalY);
      }
    });

    ctx.restore();
  },
};

export function createProductionChart(
  canvas,
  axisTitle,
  onCategoryClick = null,
  groupByTimestampCategory = false,
) {
  let categoryTokens = [];
  const chart = new Chart(canvas, {
    type: "bar",
    data: { labels: [], datasets: [] },
    plugins: groupByTimestampCategory ? [timestampCategoryAxisPlugin] : [],
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      onClick: (_event, elements) => {
        const index = elements[0]?.index;
        if (index !== undefined && onCategoryClick) {
          onCategoryClick(categoryTokens[index]);
        }
      },
      plugins: {
        legend: {
          position: "bottom",
          labels: { usePointStyle: true, boxWidth: 8, padding: 18 },
        },
        tooltip: {
          callbacks: {
            title(items) {
              const group = chart.$timestampCategoryGroups?.[items[0]?.dataIndex];
              return group
                ? `${group.intervalLabel} · ${group.categoryLabel}`
                : items[0]?.label ?? "";
            },
            label(context) {
              const value = Number(context.raw ?? 0);
              return context.dataset.yAxisID === "y1"
                ? `${context.dataset.label}: ${value.toFixed(2)}%`
                : `${context.dataset.label}: ${formatChartValue(value)}`;
            },
          },
        },
      },
      scales: {
        x: {
          title: { display: true, text: axisTitle, color: CHART_COLORS.text },
          grid: { display: false },
          ticks: {
            color: CHART_COLORS.text,
            maxRotation: 0,
            autoSkip: !groupByTimestampCategory,
            padding: groupByTimestampCategory ? 30 : 3,
            callback(value) {
              const group = chart.$timestampCategoryGroups?.[Number(value)];
              return group ? group.categoryLabel : this.getLabelForValue(value);
            },
          },
        },
        y: {
          beginAtZero: true,
          title: { display: true, text: "Pieces", color: CHART_COLORS.text },
          grid: { color: CHART_COLORS.grid },
          ticks: { color: CHART_COLORS.text, precision: 0 },
        },
        y1: {
          beginAtZero: true,
          min: 0,
          max: 100,
          position: "right",
          title: { display: true, text: "Scrap rate (%)", color: CHART_COLORS.text },
          grid: { drawOnChartArea: false },
          ticks: {
            color: CHART_COLORS.text,
            callback: (value) => `${value}%`,
          },
        },
      },
    },
  });

  return {
    chart,
    update(groups) {
      categoryTokens = groups.map((group) => group.filterToken);
      chart.$timestampCategoryGroups = groupByTimestampCategory ? groups : null;
      chart.data.labels = groupByTimestampCategory
        ? groups.map((group) => group.categoryLabel)
        : groups.map((group) => group.label);
      chart.data.datasets = [
        {
          type: "bar",
          label: "Good pieces",
          data: groups.map((group) => group.good),
          backgroundColor: CHART_COLORS.good,
          borderRadius: 3,
          yAxisID: "y",
          order: 2,
        },
        {
          type: "bar",
          label: "Scrap pieces",
          data: groups.map((group) => group.scrap),
          backgroundColor: CHART_COLORS.scrap,
          borderRadius: 3,
          yAxisID: "y",
          order: 2,
        },
        {
          type: "line",
          label: "Scrap rate (%)",
          data: groups.map((group) => group.scrapRate),
          borderColor: CHART_COLORS.rate,
          backgroundColor: CHART_COLORS.rate,
          pointBackgroundColor: CHART_COLORS.rate,
          pointRadius: 3,
          pointHoverRadius: 5,
          borderWidth: 2,
          tension: 0,
          yAxisID: "y1",
          order: 0,
        },
      ];
      chart.update("none");
    },
  };
}

export function createErrorCodeChart(canvas) {
  const chart = new Chart(canvas, {
    type: "bar",
    data: { labels: [], datasets: [] },
    plugins: [timestampCategoryAxisPlugin],
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: {
          position: "bottom",
          labels: { usePointStyle: true, boxWidth: 8, padding: 18 },
        },
        tooltip: {
          callbacks: {
            title(items) {
              const group = chart.$timestampCategoryGroups?.[items[0]?.dataIndex];
              return group ? `${group.intervalLabel} · ${group.categoryLabel}` : "";
            },
            label(context) {
              return `${context.dataset.label}: ${formatChartValue(Number(context.raw ?? 0))}`;
            },
          },
        },
      },
      scales: {
        x: {
          title: { display: true, text: "Timestamp / Error Code", color: CHART_COLORS.text },
          grid: { display: false },
          ticks: {
            color: CHART_COLORS.text,
            maxRotation: 0,
            autoSkip: false,
            padding: 30,
            callback(value) {
              const group = chart.$timestampCategoryGroups?.[Number(value)];
              return group ? group.categoryLabel : this.getLabelForValue(value);
            },
          },
        },
        y: {
          beginAtZero: true,
          title: { display: true, text: "Scrap records", color: CHART_COLORS.text },
          grid: { color: CHART_COLORS.grid },
          ticks: { color: CHART_COLORS.text, precision: 0 },
        },
      },
    },
  });

  return {
    chart,
    update(groups) {
      chart.$timestampCategoryGroups = groups;
      chart.data.labels = groups.map((group) => group.categoryLabel);
      chart.data.datasets = [
        {
          label: "Scrap records",
          data: groups.map((group) => group.count),
          backgroundColor: CHART_COLORS.scrap,
          borderRadius: 3,
        },
      ];
      chart.update("none");
    },
  };
}
