import * as XLSX from "xlsx";
import { REQUIRED_COLUMNS, WORKSHEET_NAME } from "./config.js";

function normalizeHeader(value) {
  return String(value ?? "").trim().toLocaleLowerCase();
}

function getHeaderRow(rows) {
  const index = rows.findIndex((row) =>
    row.some((value) => String(value ?? "").trim() !== ""),
  );

  if (index < 0) {
    throw new Error("The selected worksheet is empty.");
  }

  const headers = rows[index].map((value, columnIndex) => {
    const header = String(value ?? "").trim();
    return header || `Column ${columnIndex + 1}`;
  });
  const normalizedHeaders = headers.map(normalizeHeader);
  const duplicates = normalizedHeaders.filter(
    (header, duplicateIndex) => normalizedHeaders.indexOf(header) !== duplicateIndex,
  );

  if (duplicates.length > 0) {
    throw new Error("The worksheet contains duplicate column names.");
  }

  return { index, headers, normalizedHeaders };
}

function missingRequiredColumns(headers) {
  const normalized = new Set(headers.map(normalizeHeader));
  return REQUIRED_COLUMNS.filter((column) => !normalized.has(normalizeHeader(column)));
}

function getWorksheetRows(workbook, name) {
  return XLSX.utils.sheet_to_json(workbook.Sheets[name], {
    header: 1,
    raw: true,
    defval: "",
    blankrows: true,
  });
}

function dateFromExcelSerial(value, date1904) {
  if (!Number.isFinite(value) || value < 0 || value > 2958465) {
    return null;
  }

  const parts = XLSX.SSF.parse_date_code(value, { date1904 });
  if (!parts || parts.m < 1 || parts.d < 1) {
    return null;
  }

  return new Date(
    Date.UTC(parts.y, parts.m - 1, parts.d, parts.H, parts.M, parts.S, parts.u),
  );
}

function dateFromParts(year, month, day, hour, minute, second, millisecond) {
  if (
    month < 1 ||
    month > 12 ||
    day < 1 ||
    day > 31 ||
    hour < 0 ||
    hour > 23 ||
    minute < 0 ||
    minute > 59 ||
    second < 0 ||
    second > 59
  ) {
    return null;
  }

  const date = new Date(
    Date.UTC(year, month - 1, day, hour, minute, second, millisecond),
  );
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() !== month - 1 ||
    date.getUTCDate() !== day
  ) {
    return null;
  }

  return date;
}

export function parseTimestamp(value, date1904 = false) {
  if (value instanceof Date) {
    return Number.isNaN(value.getTime()) ? null : new Date(value.getTime());
  }

  if (typeof value === "number") {
    return dateFromExcelSerial(value, date1904);
  }

  if (typeof value !== "string") {
    return null;
  }

  const text = value.trim();
  if (!text) {
    return null;
  }

  if (/^[+-]?\d+(?:\.\d+)?$/.test(text)) {
    return dateFromExcelSerial(Number(text), date1904);
  }

  const calendarDate = text.match(
    /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[T ](\d{1,2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?)?$/,
  );

  if (calendarDate) {
    const [, year, month, day, hour = "0", minute = "0", second = "0", fraction = "0"] =
      calendarDate;
    return dateFromParts(
      Number(year),
      Number(month),
      Number(day),
      Number(hour),
      Number(minute),
      Number(second),
      Number(fraction.padEnd(3, "0")),
    );
  }

  const slashDate = text.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?\s*(AM|PM)?)?$/i,
  );

  if (slashDate) {
    const [, first, second, year, rawHour = "0", minute = "0", rawSecond = "0", fraction = "0", period] =
      slashDate;
    const firstPart = Number(first);
    const secondPart = Number(second);
    const month = firstPart > 12 && secondPart <= 12 ? secondPart : firstPart;
    const day = firstPart > 12 && secondPart <= 12 ? firstPart : secondPart;
    let hour = Number(rawHour);

    if (period) {
      hour = hour % 12 + (period.toLocaleUpperCase() === "PM" ? 12 : 0);
    }

    return dateFromParts(
      Number(year),
      month,
      day,
      hour,
      Number(minute),
      Number(rawSecond),
      Number(fraction.padEnd(3, "0")),
    );
  }

  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function canonicalHeader(header) {
  return (
    REQUIRED_COLUMNS.find(
      (required) => normalizeHeader(required) === normalizeHeader(header),
    ) ?? header
  );
}

function buildRecords(rows, headerIndex, headers, date1904) {
  const canonicalHeaders = headers.map(canonicalHeader);
  const timestampIndex = canonicalHeaders.indexOf("Timestamp");
  const records = [];

  for (let rowIndex = headerIndex + 1; rowIndex < rows.length; rowIndex += 1) {
    const row = rows[rowIndex];
    if (row.every((value) => String(value ?? "").trim() === "")) {
      continue;
    }

    const values = {};
    canonicalHeaders.forEach((header, columnIndex) => {
      values[header] = row[columnIndex] ?? "";
    });

    records.push({
      values,
      timestamp: parseTimestamp(row[timestampIndex], date1904),
      sourceRow: rowIndex + 1,
    });
  }

  return { headers: canonicalHeaders, records };
}

export async function processProductionFile(file) {
  if (!file) {
    throw new Error("Choose an Excel or CSV file to load.");
  }

  const extension = file.name.split(".").pop()?.toLocaleLowerCase();
  if (!["xlsx", "xls", "csv"].includes(extension)) {
    throw new Error("Choose a supported .xlsx, .xls, or .csv file.");
  }

  if (file.size === 0) {
    throw new Error("The selected file is empty.");
  }

  let workbook;
  try {
    workbook = XLSX.read(await file.arrayBuffer(), {
      type: "array",
      cellDates: false,
    });
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    throw new Error(`The selected file could not be read. ${detail}`);
  }

  if (workbook.SheetNames.length === 0) {
    throw new Error("The selected file does not contain a worksheet.");
  }

  let worksheetName = workbook.SheetNames.includes(WORKSHEET_NAME)
    ? WORKSHEET_NAME
    : null;
  let rows = worksheetName ? getWorksheetRows(workbook, worksheetName) : null;

  if (!worksheetName) {
    worksheetName = workbook.SheetNames.find((name) => {
      const candidateRows = getWorksheetRows(workbook, name);
      try {
        const { headers } = getHeaderRow(candidateRows);
        return missingRequiredColumns(headers).length === 0;
      } catch {
        return false;
      }
    });
    if (worksheetName) {
      rows = getWorksheetRows(workbook, worksheetName);
    }
  }

  if (!worksheetName || !rows) {
    worksheetName = workbook.SheetNames[0];
    rows = getWorksheetRows(workbook, worksheetName);
  }

  let header;
  try {
    header = getHeaderRow(rows);
  } catch (error) {
    throw new Error(
      `Could not read column headers from worksheet "${worksheetName}". ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
  }

  const missing = missingRequiredColumns(header.headers);
  if (missing.length > 0) {
    throw new Error(
      `Worksheet "${worksheetName}" is missing required columns: ${missing.join(", ")}.`,
    );
  }

  const { headers, records } = buildRecords(
    rows,
    header.index,
    header.headers,
    Boolean(workbook.Workbook?.WBProps?.date1904),
  );

  if (records.length === 0) {
    throw new Error(`Worksheet "${worksheetName}" contains no production records.`);
  }

  return { worksheetName, headers, records };
}
