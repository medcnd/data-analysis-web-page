import "../css/main.css";
import "../css/layout.css";
import "../css/components.css";
import "../css/dashboard.css";
import {
  APP_NAME,
  FILTER_FIELDS,
  SCRAP_TABLE_COLUMNS,
} from "./config.js";
import {
  aggregateByTime,
  aggregateByTimeAndCategory,
  aggregateScrapByTimeAndErrorCode,
  addClassifications,
  filterRecords,
  summarizeRecords,
} from "./dataProcessor.js";
import { loadDataset, saveDataset, clearDataset } from "./database.js";
import {
  bindFilterControls,
  createFilterControls,
  updateFilterOptions,
} from "./filters.js";
import { createErrorCodeChart, createProductionChart } from "./charts.js";
import { initializeScrapTable } from "./table.js";

document.title = `Production & Scrap Overview | ${APP_NAME}`;

const CHART_FILTER_KEYS = ["project", "machine", "operator", "errorCode"];
const createEmptyFilterSet = () =>
  Object.fromEntries(FILTER_FIELDS.map(({ key }) => [key, []]));

const elements = {
  loadButton: document.querySelector("[data-load-button]"),
  clearButton: document.querySelector("[data-clear-button]"),
  fileInput: document.querySelector("[data-file-input]"),
  filterControls: document.querySelector("[data-filter-controls]"),
  chartFilterContainers: Object.fromEntries(
    [...document.querySelectorAll("[data-chart-filter-container]")].map((container) => [
      container.dataset.chartFilterContainer,
      container,
    ]),
  ),
  resetFilters: document.querySelector("[data-reset-filters]"),
  timeGrouping: document.querySelector("[data-time-grouping]"),
  chartGroupings: Object.fromEntries(
    [...document.querySelectorAll("[data-chart-time-grouping]")].map((select) => [
      select.dataset.chartTimeGrouping,
      select,
    ]),
  ),
  datasetInfo: document.querySelector("[data-dataset-info]"),
  selectionSummary: document.querySelector("[data-selection-summary]"),
  notice: document.querySelector("[data-notice]"),
  loading: document.querySelector("[data-loading]"),
  loadingText: document.querySelector("[data-loading-text]"),
  tableBody: document.querySelector("[data-scrap-rows]"),
  tableSearch: document.querySelector("[data-table-search]"),
  scrapCount: document.querySelector("[data-scrap-count]"),
  tableRange: document.querySelector("[data-table-range]"),
  pageNumber: document.querySelector("[data-page-number]"),
  previousPage: document.querySelector("[data-page-previous]"),
  nextPage: document.querySelector("[data-page-next]"),
  exportButton: document.querySelector("[data-export-button]"),
  detailsDialog: document.querySelector("[data-record-dialog]"),
  detailsTitle: document.querySelector("[data-details-title]"),
  detailsContent: document.querySelector("[data-details-content]"),
  closeDetails: document.querySelector("[data-close-details]"),
};

const state = {
  dataset: null,
  busy: false,
  filters: createEmptyFilterSet(),
  chartFilters: Object.fromEntries(
    CHART_FILTER_KEYS.map((key) => [key, createEmptyFilterSet()]),
  ),
};

let noticeTimeout;

function showNotice(message, type = "info") {
  window.clearTimeout(noticeTimeout);
  elements.notice.textContent = message;
  elements.notice.className = `notice notice-${type}`;
  elements.notice.setAttribute("role", type === "error" ? "alert" : "status");
  elements.notice.hidden = !message;
  if (message) {
    noticeTimeout = window.setTimeout(() => {
      elements.notice.hidden = true;
    }, type === "error" ? 12000 : 7000);
  }
}

function setBusy(isBusy, message = "Processing report…") {
  state.busy = isBusy;
  elements.loading.hidden = !isBusy;
  elements.loadingText.textContent = message;
  elements.loadButton.disabled = isBusy;
  elements.clearButton.disabled = isBusy || !state.dataset;
}

function formatUploadDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "Unknown";
  }
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function updateDatasetSummary(records) {
  if (!state.dataset) {
    elements.datasetInfo.textContent =
      "No dataset loaded. For testing, choose AMATEC Airbag.xlsx from your files.";
    elements.selectionSummary.textContent =
      "Your uploaded data remains on this browser and device.";
    return;
  }

  const summary = summarizeRecords(records);
  elements.datasetInfo.textContent =
    `${state.dataset.fileName} · ${state.dataset.records.length.toLocaleString()} imported records · ` +
    `Last successful upload: ${formatUploadDate(state.dataset.importedAt)} · ` +
    `Worksheet: ${state.dataset.worksheetName}`;

  let selectionText =
    `Current selection: ${summary.totalRecords.toLocaleString()} records · ` +
    `${summary.totalPieces.toLocaleString()} classified pieces ` +
    `(${summary.good.toLocaleString()} good, ${summary.scrap.toLocaleString()} scrap) · ` +
    `Scrap rate ${summary.scrapRate.toFixed(2)}% · ` +
    `${summary.unclassified.toLocaleString()} unclassified Error Code`;

  if (summary.invalidTimestamps > 0) {
    selectionText += ` · ${summary.invalidTimestamps.toLocaleString()} invalid Timestamp values omitted from the time chart`;
  }

  elements.selectionSummary.textContent = selectionText;
}

const charts = {
  time: createProductionChart(
    document.querySelector('[data-chart="time"]'),
    "Timestamp interval",
  ),
  project: createProductionChart(
    document.querySelector('[data-chart="project"]'),
    "Timestamp / Project",
    (token) => applyChartFilter("project", "Type Group", token),
    true,
  ),
  machine: createProductionChart(
    document.querySelector('[data-chart="machine"]'),
    "Timestamp / Machine",
    (token) => applyChartFilter("machine", "Machine ID", token),
    true,
  ),
  operator: createProductionChart(
    document.querySelector('[data-chart="operator"]'),
    "Timestamp / Operator",
    (token) => applyChartFilter("operator", "Login Name", token),
    true,
  ),
  errorCode: createErrorCodeChart(document.querySelector('[data-chart="errorCode"]')),
};

const scrapTable = initializeScrapTable({
  tableBody: elements.tableBody,
  searchInput: elements.tableSearch,
  countText: elements.scrapCount,
  rangeText: elements.tableRange,
  pageText: elements.pageNumber,
  previousButton: elements.previousPage,
  nextButton: elements.nextPage,
  exportButton: elements.exportButton,
  dialog: elements.detailsDialog,
  dialogTitle: elements.detailsTitle,
  dialogContent: elements.detailsContent,
  onExportError(error) {
    const detail = error instanceof Error ? error.message : String(error);
    showNotice(`Could not export the filtered scrap records. ${detail}`, "error");
  },
});

function getRecords() {
  return state.dataset?.records ?? [];
}

function renderChart(key, groups) {
  charts[key].update(groups);
  document.querySelector(`[data-chart-empty="${key}"]`).hidden = groups.length > 0;
}

function renderDashboard() {
  const records = getRecords();
  updateFilterOptions(elements.filterControls, records, state.filters);
  CHART_FILTER_KEYS.forEach((key) => {
    updateFilterOptions(
      elements.chartFilterContainers[key].querySelector("[data-filter-controls]"),
      records,
      state.chartFilters[key],
    );
  });
  const filteredRecords = filterRecords(records, state.filters);
  const timeGrouping = elements.timeGrouping.value;

  updateDatasetSummary(filteredRecords);
  renderChart("time", aggregateByTime(filteredRecords, timeGrouping));
  renderChart(
    "project",
    aggregateByTimeAndCategory(
      filterRecords(records, state.chartFilters.project),
      elements.chartGroupings.project.value,
      "Type Group",
    ),
  );
  renderChart(
    "machine",
    aggregateByTimeAndCategory(
      filterRecords(records, state.chartFilters.machine),
      elements.chartGroupings.machine.value,
      "Machine ID",
    ),
  );
  renderChart(
    "operator",
    aggregateByTimeAndCategory(
      filterRecords(records, state.chartFilters.operator),
      elements.chartGroupings.operator.value,
      "Login Name",
    ),
  );
  renderChart(
    "errorCode",
    aggregateScrapByTimeAndErrorCode(
      filterRecords(records, state.chartFilters.errorCode),
      elements.chartGroupings.errorCode.value,
    ),
  );

  const scrapRecords = filteredRecords.filter(
    (record) => record.classification === "scrap",
  );
  scrapTable.update(scrapRecords, state.dataset?.headers ?? SCRAP_TABLE_COLUMNS);
  elements.clearButton.disabled = state.busy || !state.dataset;
}

function applyChartFilter(chartKey, field, token) {
  if (!token) {
    return;
  }

  const selectedValues = state.chartFilters[chartKey][field];
  state.chartFilters[chartKey][field] = selectedValues.includes(token)
    ? selectedValues.filter((value) => value !== token)
    : [...selectedValues, token];
  renderDashboard();
}

function resetFilterSet(filters) {
  FILTER_FIELDS.forEach(({ key }) => {
    filters[key] = [];
  });
}

function resetAllFilters() {
  resetFilterSet(state.filters);
  CHART_FILTER_KEYS.forEach((key) => resetFilterSet(state.chartFilters[key]));
}

createFilterControls(elements.filterControls);
bindFilterControls(
  elements.filterControls,
  getRecords,
  state.filters,
  renderDashboard,
);

CHART_FILTER_KEYS.forEach((key) => {
  const container = elements.chartFilterContainers[key];
  const controls = container.querySelector("[data-filter-controls]");
  createFilterControls(controls);
  bindFilterControls(controls, getRecords, state.chartFilters[key], renderDashboard);
  container
    .querySelector(`[data-reset-chart-filters="${key}"]`)
    .addEventListener("click", () => {
      resetFilterSet(state.chartFilters[key]);
      renderDashboard();
    });
});

elements.resetFilters.addEventListener("click", () => {
  resetFilterSet(state.filters);
  renderDashboard();
});

elements.timeGrouping.addEventListener("change", renderDashboard);
Object.values(elements.chartGroupings).forEach((select) => {
  select.addEventListener("change", renderDashboard);
});
elements.loadButton.addEventListener("click", () => elements.fileInput.click());
elements.fileInput.addEventListener("change", async () => {
  const file = elements.fileInput.files?.[0];
  if (!file) {
    return;
  }

  showNotice("");
  setBusy(true, `Reading ${file.name}…`);
  try {
    const { processProductionFile } = await import("./excelProcessor.js");
    const parsed = await processProductionFile(file);
    const dataset = {
      fileName: file.name,
      importedAt: new Date().toISOString(),
      worksheetName: parsed.worksheetName,
      headers: parsed.headers,
      records: addClassifications(parsed.records),
    };

    setBusy(true, "Saving the validated dataset in this browser…");
    await saveDataset(dataset);
    state.dataset = dataset;
    resetAllFilters();
    elements.tableSearch.value = "";
    renderDashboard();

    const summary = summarizeRecords(dataset.records);
    showNotice(
      `${file.name} loaded: ${summary.totalRecords.toLocaleString()} records · ` +
        `${summary.good.toLocaleString()} good · ${summary.scrap.toLocaleString()} scrap · ` +
        `${summary.unclassified.toLocaleString()} unclassified.`,
      "success",
    );
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    showNotice(`The new dataset was not loaded. ${detail}`, "error");
  } finally {
    elements.fileInput.value = "";
    setBusy(false);
  }
});

elements.clearButton.addEventListener("click", async () => {
  if (
    !state.dataset ||
    !window.confirm("Remove the saved production report from this browser?")
  ) {
    return;
  }

  showNotice("");
  setBusy(true, "Removing the saved dataset…");
  try {
    await clearDataset();
    state.dataset = null;
    resetAllFilters();
    elements.tableSearch.value = "";
    renderDashboard();
    showNotice("The saved dataset was removed from this browser.", "success");
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    showNotice(`Could not remove the saved dataset. ${detail}`, "error");
  } finally {
    setBusy(false);
  }
});

elements.closeDetails.addEventListener("click", () => elements.detailsDialog.close());
elements.detailsDialog.addEventListener("click", (event) => {
  if (event.target === elements.detailsDialog) {
    elements.detailsDialog.close();
  }
});

async function restoreDataset() {
  setBusy(true, "Checking this browser for a saved dataset…");
  try {
    const savedDataset = await loadDataset();
    if (savedDataset) {
      if (!Array.isArray(savedDataset.records) || !Array.isArray(savedDataset.headers)) {
        throw new Error("The saved dataset is incomplete. Clear it and upload the report again.");
      }
      state.dataset = savedDataset;
      renderDashboard();
    } else {
      renderDashboard();
    }
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    showNotice(`Could not restore a saved dataset. ${detail}`, "error");
    renderDashboard();
  } finally {
    setBusy(false);
  }
}

void restoreDataset();
