import { FILTER_FIELDS } from "./config.js";

export const BLANK_FILTER_TOKEN = "__blank_value__";

export function classifyErrorCode(value) {
  if (value === null || value === undefined || String(value).trim() === "") {
    return "unclassified";
  }

  const numericValue = typeof value === "number" ? value : Number(String(value).trim());
  if (!Number.isFinite(numericValue)) {
    return "unclassified";
  }

  return numericValue === 0 ? "good" : "scrap";
}

export function addClassifications(records) {
  return records.map((record) => ({
    ...record,
    classification: classifyErrorCode(record.values["Error Code"]),
  }));
}

export function valueToFilterToken(value) {
  const text = String(value ?? "").trim();
  return text === "" ? BLANK_FILTER_TOKEN : `value:${text}`;
}

export function displayFilterValue(value) {
  const text = String(value ?? "").trim();
  return text || "(Blank)";
}

export function filterRecords(records, filters, excludedField = null) {
  return records.filter((record) =>
    FILTER_FIELDS.every(({ key }) => {
      const selected = filters[key];
      const selectedValues = Array.isArray(selected)
        ? selected
        : selected
          ? [selected]
          : [];
      return (
        key === excludedField ||
        selectedValues.length === 0 ||
        selectedValues.includes(valueToFilterToken(record.values[key]))
      );
    }),
  );
}

export function summarizeRecords(records) {
  const summary = {
    totalRecords: records.length,
    totalPieces: 0,
    good: 0,
    scrap: 0,
    unclassified: 0,
    invalidTimestamps: 0,
    scrapRate: 0,
  };

  records.forEach((record) => {
    if (record.classification === "good") {
      summary.good += 1;
    } else if (record.classification === "scrap") {
      summary.scrap += 1;
    } else {
      summary.unclassified += 1;
    }

    if (!(record.timestamp instanceof Date) || Number.isNaN(record.timestamp.getTime())) {
      summary.invalidTimestamps += 1;
    }
  });

  summary.totalPieces = summary.good + summary.scrap;
  summary.scrapRate = summary.totalPieces
    ? (summary.scrap / summary.totalPieces) * 100
    : 0;

  return summary;
}

function createCounts(label, key, filterToken) {
  return {
    label,
    key,
    filterToken,
    good: 0,
    scrap: 0,
    scrapRate: 0,
  };
}

function finishGroup(group) {
  const total = group.good + group.scrap;
  group.scrapRate = total ? (group.scrap / total) * 100 : 0;
  return group;
}

export function aggregateByCategory(records, field) {
  const groups = new Map();

  records.forEach((record) => {
    if (record.classification === "unclassified") {
      return;
    }

    const value = record.values[field];
    const filterToken = valueToFilterToken(value);
    if (!groups.has(filterToken)) {
      groups.set(
        filterToken,
        createCounts(displayFilterValue(value), filterToken, filterToken),
      );
    }

    const group = groups.get(filterToken);
    group[record.classification] += 1;
  });

  return [...groups.values()]
    .map(finishGroup)
    .sort((left, right) =>
      left.label.localeCompare(right.label, undefined, { numeric: true, sensitivity: "base" }),
    );
}

function pad(value) {
  return String(value).padStart(2, "0");
}

function getTimeInterval(date, grouping) {
  const year = date.getUTCFullYear();
  const month = pad(date.getUTCMonth() + 1);
  const day = pad(date.getUTCDate());
  const hour = pad(date.getUTCHours());
  const shortDateLabel = new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(date);
  const fullDateLabel = new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  }).format(date);

  if (grouping === "hour") {
    return {
      key: `${year}-${month}-${day}T${hour}`,
      label: `${fullDateLabel} · ${hour}:00`,
      axisLabel: `${shortDateLabel} ${hour}:00`,
    };
  }

  if (grouping === "month") {
    const label = new Intl.DateTimeFormat(undefined, {
      month: "short",
      year: "numeric",
      timeZone: "UTC",
    }).format(date);
    return {
      key: `${year}-${month}`,
      label,
      axisLabel: label,
    };
  }

  return {
    key: `${year}-${month}-${day}`,
    label: fullDateLabel,
    axisLabel: shortDateLabel,
  };
}

export function aggregateByTime(records, grouping) {
  const groups = new Map();

  records.forEach((record) => {
    if (
      record.classification === "unclassified" ||
      !(record.timestamp instanceof Date) ||
      Number.isNaN(record.timestamp.getTime())
    ) {
      return;
    }

    const interval = getTimeInterval(record.timestamp, grouping);
    if (!groups.has(interval.key)) {
      groups.set(interval.key, createCounts(interval.label, interval.key, null));
    }

    const group = groups.get(interval.key);
    group[record.classification] += 1;
  });

  return [...groups.values()]
    .sort((left, right) => left.key.localeCompare(right.key))
    .map(finishGroup);
}

export function aggregateByTimeAndCategory(records, grouping, field) {
  const groups = new Map();

  records.forEach((record) => {
    if (
      record.classification === "unclassified" ||
      !(record.timestamp instanceof Date) ||
      Number.isNaN(record.timestamp.getTime())
    ) {
      return;
    }

    const interval = getTimeInterval(record.timestamp, grouping);
    const value = record.values[field];
    const filterToken = valueToFilterToken(value);
    const categoryLabel = displayFilterValue(value);
    const key = JSON.stringify([interval.key, filterToken]);

    if (!groups.has(key)) {
      groups.set(key, {
        ...createCounts(categoryLabel, key, filterToken),
        intervalKey: interval.key,
        intervalLabel: interval.label,
        timeGroupLabel: interval.axisLabel,
        categoryLabel,
      });
    }

    const group = groups.get(key);
    group[record.classification] += 1;
  });

  return [...groups.values()]
    .sort(
      (left, right) =>
        left.intervalKey.localeCompare(right.intervalKey) ||
        left.categoryLabel.localeCompare(right.categoryLabel, undefined, {
          numeric: true,
          sensitivity: "base",
        }),
    )
    .map(finishGroup);
}

export function aggregateScrapByTimeAndErrorCode(records, grouping) {
  const groups = new Map();

  records.forEach((record) => {
    if (
      record.classification !== "scrap" ||
      !(record.timestamp instanceof Date) ||
      Number.isNaN(record.timestamp.getTime())
    ) {
      return;
    }

    const interval = getTimeInterval(record.timestamp, grouping);
    const code = String(Number(String(record.values["Error Code"]).trim()));
    const key = JSON.stringify([interval.key, code]);

    if (!groups.has(key)) {
      groups.set(key, {
        key,
        label: code,
        intervalKey: interval.key,
        intervalLabel: interval.label,
        timeGroupLabel: interval.axisLabel,
        categoryLabel: code,
        code,
        count: 0,
      });
    }

    groups.get(key).count += 1;
  });

  return [...groups.values()].sort(
    (left, right) =>
      left.intervalKey.localeCompare(right.intervalKey) ||
      Number(left.code) - Number(right.code),
  );
}

export function formatTimestamp(date) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    return "—";
  }

  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "UTC",
  }).format(date);
}
